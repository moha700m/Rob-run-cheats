# Rob Run Overlay — Full Handoff for GPT

You are a coding agent with shell access and a GitHub account authenticated via the `gh` CLI. Your job is to materialize this project locally, create a new private GitHub repository, push the code, and verify that the GitHub Actions workflow builds `RobRunOverlay.exe`.

Follow the steps **in order**. Do not skip any file. Every file listed in the **File Manifest** must be created with its exact contents — paths, filenames, and bytes as given.

---

## 0. Prerequisites to confirm

Before starting, confirm the shell has:

```bash
git --version
gh --version
gh auth status
```

If `gh` is not authenticated, run `gh auth login` and continue once it reports a logged-in user.

---

## 1. Create the project directory

```bash
mkdir -p robrun-overlay
cd robrun-overlay
mkdir -p src .github/workflows
```

---

## 2. Write every file from the File Manifest

Create each file listed in the **File Manifest** section below at the exact relative path shown in its heading. Use a heredoc or your file-writing tool. **Do not alter the contents.** The project builds only if every byte matches.

Expected tree after this step:

```
robrun-overlay/
├── .github/workflows/build.yml
├── .gitignore
├── CMakeLists.txt
├── README.md
└── src/
    ├── Config.h
    ├── ESP.cpp
    ├── ESP.h
    ├── Math.h
    ├── Memory.h
    ├── Overlay.cpp
    ├── Overlay.h
    ├── Process.h
    ├── SDK.h
    ├── World.h
    └── main.cpp
```

Verify with:

```bash
find . -type f | sort
```

Must list exactly 13 files (plus the `HANDOFF.md` you may have placed alongside).

---

## 3. Initialize the local git repo

```bash
git init -b main
git add .
git commit -m "Initial commit: Rob Run external overlay scaffold"
```

---

## 4. Create the GitHub repository and push

Pick a short slug (default: `robrun-overlay`). Create as **private**:

```bash
gh repo create robrun-overlay --private --source=. --remote=origin --push
```

If the repo already exists, instead run:

```bash
git remote add origin git@github.com:$(gh api user --jq .login)/robrun-overlay.git
git push -u origin main
```

Confirm the push:

```bash
gh repo view --web
```

---

## 5. Verify GitHub Actions

The workflow at `.github/workflows/build.yml` fires on every push to `main`. After step 4, check its run:

```bash
gh run list --limit 1
gh run watch
```

Expected outcome: a successful build job on `windows-latest` that produces an artifact named `RobRunOverlay-<sha>` containing `RobRunOverlay.zip`.

If the build fails, download the logs:

```bash
gh run view --log-failed
```

Common first-build failures and their fix:

| Symptom                                           | Fix                                                                 |
|---------------------------------------------------|---------------------------------------------------------------------|
| `imgui.h not found`                               | The ImGui clone step did not run. Re-check `build.yml` is verbatim. |
| MSBuild unable to find toolset                    | `microsoft/setup-msbuild@v2` step missing — re-check `build.yml`.   |
| Linker: `d3d11.lib not found`                     | Windows SDK not on the runner. Use `windows-latest`, not `ubuntu`.  |

---

## 6. Tag a release (optional, after first green build)

```bash
git tag v0.1.0
git push origin v0.1.0
```

The workflow's `Publish release (on tag)` job will attach `RobRunOverlay.zip` to a GitHub release automatically.

---

## 7. Report back

When finished, report:

- The repository URL (`gh repo view --json url --jq .url`)
- The latest workflow run status (`gh run list --limit 1`)
- The artifact download URL if the build succeeded

Do **not** modify any `SDK.h` offsets or any `// FILL:` markers. Those are intentional — the project owner will fill them against the live `RobRun.exe` build.

---

# File Manifest

Each heading below is a file to create. The code fence directly under it is its full content. Reproduce exactly.


## `CMakeLists.txt`

```cmake
# CMakeLists.txt - Build the Rob Run external overlay.
#
# Prereqs:
#   - Visual Studio 2022 (MSVC v143) or Build Tools, x64 toolchain
#   - CMake 3.21+
#   - Dear ImGui sources checked out into vendor/imgui (see README)
#
# Build:
#   cmake -B build -S . -A x64
#   cmake --build build --config Release
# Output: build/Release/RobRunOverlay.exe

cmake_minimum_required(VERSION 3.21)
project(RobRunOverlay LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

if(NOT WIN32)
    message(FATAL_ERROR "This project targets Windows only.")
endif()

# --- ImGui -------------------------------------------------------------------
set(IMGUI_DIR "${CMAKE_SOURCE_DIR}/vendor/imgui")

if(NOT EXISTS "${IMGUI_DIR}/imgui.h")
    message(FATAL_ERROR
        "Dear ImGui sources not found at ${IMGUI_DIR}.\n"
        "Clone them with:\n"
        "  git clone --depth 1 https://github.com/ocornut/imgui vendor/imgui")
endif()

set(IMGUI_SOURCES
    "${IMGUI_DIR}/imgui.cpp"
    "${IMGUI_DIR}/imgui_draw.cpp"
    "${IMGUI_DIR}/imgui_tables.cpp"
    "${IMGUI_DIR}/imgui_widgets.cpp"
    "${IMGUI_DIR}/imgui_demo.cpp"
    "${IMGUI_DIR}/backends/imgui_impl_win32.cpp"
    "${IMGUI_DIR}/backends/imgui_impl_dx11.cpp"
)

# --- Overlay executable ------------------------------------------------------
add_executable(RobRunOverlay WIN32
    src/main.cpp
    src/Overlay.cpp
    src/ESP.cpp
    ${IMGUI_SOURCES}
)

target_include_directories(RobRunOverlay PRIVATE
    src
    "${IMGUI_DIR}"
    "${IMGUI_DIR}/backends"
)

target_compile_definitions(RobRunOverlay PRIVATE
    UNICODE _UNICODE
    WIN32_LEAN_AND_MEAN
    NOMINMAX
)

target_link_libraries(RobRunOverlay PRIVATE
    d3d11
    dxgi
    dwmapi
    psapi
)

# Strip CRT down for a smaller binary (optional).
if(MSVC)
    target_compile_options(RobRunOverlay PRIVATE /W4 /permissive- /MP)
    set_property(TARGET RobRunOverlay PROPERTY
        MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
endif()
```


## `.gitignore`

```gitignore
# Build output
build/
dist/
out/
cmake-build-*/
*.exe
*.pdb
*.obj
*.ilk
*.exp
*.lib

# Vendor (fetched by CI / local build)
vendor/

# IDE
.vs/
.vscode/
.idea/
*.user
*.suo
*.sln.docstates
CMakeCache.txt
CMakeFiles/
CMakeScripts/
cmake_install.cmake
Makefile

# OS
Thumbs.db
.DS_Store
```


## `README.md`

```markdown
# Rob Run — External Overlay

External, read-only overlay. Finds `RobRun.exe`, opens a transparent click-through DX11 window over it, draws ImGui ESP (boxes, names, HP bars, distance, snaplines, crosshair, FOV circle).

Pure `ReadProcessMemory` — no injection, no hooks, no writes. All cheat logic lives outside the game process.

## Build

```bat
git clone --depth 1 https://github.com/ocornut/imgui vendor/imgui
cmake -B build -S . -A x64
cmake --build build --config Release
```

Output: `build/Release/RobRunOverlay.exe`.

Run **as administrator** if the game is launched with elevation (common on anti-cheat protected titles).

## Runtime

| Key    | Action                        |
|--------|-------------------------------|
| INSERT | Toggle config menu            |
| END    | Quit overlay                  |

The overlay attaches automatically and re-attaches if the game is closed and reopened.

## Filling in the offsets

Everything in the framework is build-agnostic **except** `src/SDK.h`. Each `// FILL:` line is one value to dump against the current `RobRun.exe` build. You need:

**Module-relative (static) offsets:**
- `kLocalPlayer`  — pointer-to-pointer to the local player struct
- `kEntityList`   — pointer to the array of entity pointers
- `kEntityCount`  — int: number of active entities (optional; falls back to `kMaxEntities`)
- `kViewMatrix`   — 4x4 float, row-major view-projection matrix
- `kGameState`    — int or bool, non-zero in a match (optional)

**Per-entity offsets** (relative to each `Entity*`):
- `kPosition`   — `Vec3` world position (float x/y/z)
- `kHealth`, `kMaxHealth` — floats
- `kTeam`       — int team id
- `kIsAlive`    — bool / int
- `kName`       — inline `char[32]` or `char*`
- `kBonePosHead` — optional, only if you want head boxes / snaplines to head
- `kVisible`    — optional visibility flag

### How to find them

1. **Cheat Engine** — attach to `RobRun.exe`, scan for your known HP value, narrow by taking damage, find a pointer path. Repeat for each field. "Find what accesses this address" gives you the instruction, then "Browse memory region" / Mono / dissect data structure maps out the entity layout.
2. **ReClass.NET** — paste the entity pointer, walk the struct interactively. Great for discovering `Position`, `Health`, `Team` fields visually.
3. **IDA / Ghidra / x64dbg** — for patch-stable signatures. Find the instruction that reads `g_LocalPlayer`, extract the surrounding bytes (10–12 bytes with wildcards on relative operands), feed it to `mem::findPattern` + `mem::resolveRip` at runtime instead of hard-coding the offset. That version survives small patches.

The scanner in `src/Memory.h` accepts IDA-style signatures (`"48 8B 05 ? ? ? ?"`). Swap any raw `kFoo = 0xABC` for a scan at startup once you have a signature.

## Layout

```
robrun-overlay/
  CMakeLists.txt
  README.md
  src/
    main.cpp         entry point, hotkeys, lifecycle
    Overlay.h/.cpp   DX11 transparent window + ImGui
    ESP.h/.cpp       ESP draws + settings menu
    World.h          one-tick world snapshot (RPM)
    Process.h        attach, module base, templated RPM
    Memory.h         IDA-style pattern scan + RIP resolver
    SDK.h            game offsets (the one file to edit per patch)
    Math.h           Vec2/Vec3/Matrix4 + world-to-screen
    Config.h         runtime settings
```

## Notes

- **External only.** The overlay never writes to the game, never allocates inside it, never injects. Reads are rate-limitable via `Config::readIntervalMs` to keep RPM pressure low.
- **View matrix layout.** `Math::worldToScreen` assumes row-major. If positions project to the wrong quadrant, your view matrix is column-major — transpose on read or flip the indexing in `worldToScreen`.
- **Entity stride.** Default is `sizeof(void*)` — change in `SDK.h` if the game uses an array of inline structs instead of pointers.
- **Click-through.** Window is `WS_EX_TRANSPARENT` by default; `setInteractive(true)` flips it off while the menu is open so ImGui can receive input.
```


## `.github/workflows/build.yml`

```yaml
name: Build

on:
  push:
    branches: [main, master]
    tags: ['v*']
  pull_request:
    branches: [main, master]
  workflow_dispatch:

jobs:
  build:
    runs-on: windows-latest

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Clone Dear ImGui
        shell: pwsh
        run: git clone --depth 1 https://github.com/ocornut/imgui vendor/imgui

      - name: Add MSBuild to PATH
        uses: microsoft/setup-msbuild@v2

      - name: Configure CMake (x64, Release)
        shell: pwsh
        run: cmake -B build -S . -A x64

      - name: Build
        shell: pwsh
        run: cmake --build build --config Release --parallel

      - name: Collect artifact
        shell: pwsh
        run: |
          New-Item -ItemType Directory -Force -Path dist | Out-Null
          Copy-Item build/Release/RobRunOverlay.exe dist/
          Copy-Item README.md dist/
          Compress-Archive -Path dist/* -DestinationPath RobRunOverlay.zip -Force

      - name: Upload build artifact
        uses: actions/upload-artifact@v4
        with:
          name: RobRunOverlay-${{ github.sha }}
          path: RobRunOverlay.zip
          if-no-files-found: error

      - name: Publish release (on tag)
        if: startsWith(github.ref, 'refs/tags/v')
        uses: softprops/action-gh-release@v2
        with:
          files: RobRunOverlay.zip
          generate_release_notes: true
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```


## `src/SDK.h`

```cpp
// SDK.h - Rob Run game-specific offsets, structures, and constants.
//
// These values are tied to a specific build of RobRun.exe. When the game
// updates they will usually need to be re-dumped. Dump them with Cheat Engine,
// IDA, ReClass.NET, or x64dbg against the live process.
//
// Replace each `// FILL:` value with the offset / size found in your dump.
// Everything else in the project is build-agnostic and will not need to change.

#pragma once
#include <cstdint>

namespace sdk {

    // ---- Process targeting ---------------------------------------------------
    inline constexpr const wchar_t* kProcessName = L"RobRun.exe";
    inline constexpr const wchar_t* kWindowName  = L"Rob Run";          // visible window title; adjust if different
    inline constexpr const wchar_t* kMainModule  = L"RobRun.exe";       // module whose base we anchor offsets to

    // ---- Module-relative offsets --------------------------------------------
    // Resolved as: moduleBase + offset -> (optional pointer chain) -> value
    namespace off {
        // Pointer to the local player structure.
        // Typical pattern: static ptr -> LocalPlayer*
        inline constexpr uintptr_t kLocalPlayer   = 0x0;   // FILL: pattern "48 8B 05 ? ? ? ? 48 85 C0 74 ? 48 8B 80"

        // Pointer to the entity list (array of Entity*).
        inline constexpr uintptr_t kEntityList    = 0x0;   // FILL: pattern "48 8B 0D ? ? ? ? E8 ? ? ? ? 48 8B C8 E8"

        // Maximum entity count (number of slots in the list).
        inline constexpr uintptr_t kEntityCount   = 0x0;   // FILL: often a sibling of EntityList

        // View matrix used for world-to-screen (row-major 4x4 float).
        inline constexpr uintptr_t kViewMatrix    = 0x0;   // FILL: pattern "48 8D 0D ? ? ? ? 48 C1 E0 06"

        // Game state / in-match flag — used to hide ESP on menu screens.
        inline constexpr uintptr_t kGameState     = 0x0;   // FILL
    }

    // ---- Per-entity offsets (relative to an Entity* struct) -----------------
    namespace ent {
        inline constexpr uintptr_t kPosition      = 0x0;   // FILL: Vec3 world position
        inline constexpr uintptr_t kRotation      = 0x0;   // FILL: Vec3 or quaternion
        inline constexpr uintptr_t kHealth        = 0x0;   // FILL: int / float HP
        inline constexpr uintptr_t kMaxHealth     = 0x0;   // FILL
        inline constexpr uintptr_t kTeam          = 0x0;   // FILL: int team id
        inline constexpr uintptr_t kName          = 0x0;   // FILL: inline char[32] or pointer to string
        inline constexpr uintptr_t kIsAlive       = 0x0;   // FILL: bool / int
        inline constexpr uintptr_t kIsLocal       = 0x0;   // FILL: bool flag, OR compare address to LocalPlayer
        inline constexpr uintptr_t kBonePosHead   = 0x0;   // FILL: optional, for head-aim / head box
        inline constexpr uintptr_t kVisible       = 0x0;   // FILL: optional visibility flag
    }

    // Entity list stride — size of each pointer slot. Usually sizeof(void*) = 8.
    inline constexpr size_t kEntityStride = sizeof(void*);

    // Expected / sane maximum, fallback if kEntityCount is 0.
    inline constexpr int kMaxEntities = 128;

    // Team id of the local player's team — used to tell friends from enemies.
    // Read dynamically from the local player; this is just a fallback.
    inline constexpr int kFallbackLocalTeam = -1;
}
```


## `src/Math.h`

```cpp
// Math.h - Vector / matrix math and world-to-screen projection.

#pragma once
#include <cmath>
#include <cstdint>

struct Vec2 {
    float x = 0.f, y = 0.f;

    Vec2 operator+(const Vec2& o) const { return { x + o.x, y + o.y }; }
    Vec2 operator-(const Vec2& o) const { return { x - o.x, y - o.y }; }
    Vec2 operator*(float s)      const { return { x * s, y * s }; }
    float length() const { return std::sqrt(x * x + y * y); }
};

struct Vec3 {
    float x = 0.f, y = 0.f, z = 0.f;

    Vec3 operator+(const Vec3& o) const { return { x + o.x, y + o.y, z + o.z }; }
    Vec3 operator-(const Vec3& o) const { return { x - o.x, y - o.y, z - o.z }; }
    Vec3 operator*(float s)      const { return { x * s, y * s, z * s }; }
    float dot(const Vec3& o) const { return x * o.x + y * o.y + z * o.z; }
    float length() const { return std::sqrt(x * x + y * y + z * z); }
    float distanceTo(const Vec3& o) const { return (*this - o).length(); }
};

// Row-major 4x4 view-projection matrix, as commonly laid out in memory for
// DirectX / Unreal / Unity titles. If the game stores column-major, swap the
// indexing in worldToScreen below (or transpose on read).
struct Matrix4 {
    float m[4][4] = {};
};

// Project a world-space position onto screen-space using the view-projection
// matrix. Returns true if the point is in front of the camera; false if
// behind, which the caller should treat as "do not draw".
//
// screenW / screenH are the game viewport dimensions in pixels.
inline bool worldToScreen(const Vec3& world,
                          const Matrix4& vp,
                          float screenW,
                          float screenH,
                          Vec2& out) {
    const float clipX = world.x * vp.m[0][0] + world.y * vp.m[1][0] +
                        world.z * vp.m[2][0] + vp.m[3][0];
    const float clipY = world.x * vp.m[0][1] + world.y * vp.m[1][1] +
                        world.z * vp.m[2][1] + vp.m[3][1];
    const float clipW = world.x * vp.m[0][3] + world.y * vp.m[1][3] +
                        world.z * vp.m[2][3] + vp.m[3][3];

    if (clipW < 0.01f) {
        return false; // behind camera
    }

    const float ndcX = clipX / clipW;
    const float ndcY = clipY / clipW;

    out.x = (screenW * 0.5f) + (ndcX * screenW * 0.5f);
    out.y = (screenH * 0.5f) - (ndcY * screenH * 0.5f);
    return true;
}

// Build a screen-space AABB around a world position, sized by distance.
// Returns false if the position does not project.
inline bool worldBoxToScreen(const Vec3& feet,
                             float worldHeight,
                             float worldWidth,
                             const Matrix4& vp,
                             float screenW,
                             float screenH,
                             Vec2& topLeft,
                             Vec2& bottomRight) {
    Vec2 head2d, feet2d;
    const Vec3 head = { feet.x, feet.y, feet.z + worldHeight };
    if (!worldToScreen(feet, vp, screenW, screenH, feet2d)) return false;
    if (!worldToScreen(head, vp, screenW, screenH, head2d)) return false;

    const float height = std::fabs(feet2d.y - head2d.y);
    const float width  = height * (worldWidth / worldHeight);
    const float cx     = (feet2d.x + head2d.x) * 0.5f;

    topLeft     = { cx - width * 0.5f, head2d.y };
    bottomRight = { cx + width * 0.5f, feet2d.y };
    return true;
}
```


## `src/Config.h`

```cpp
// Config.h - Runtime-toggleable cheat settings. Rendered as the ImGui menu.

#pragma once
#include <cstdint>

struct Config {
    // Master
    bool enabled          = true;
    bool showMenu         = true;    // toggled with INSERT

    // ESP toggles
    bool espBox           = true;
    bool espName          = true;
    bool espHealthBar     = true;
    bool espDistance      = true;
    bool espSnapline      = false;
    bool espSkeleton      = false;   // requires bone offsets
    bool espTeamCheck     = true;    // hide teammates

    // Filters
    float maxDistance     = 300.0f;  // world units
    float minDistance     = 0.0f;

    // Crosshair / FOV
    bool  drawCrosshair   = false;
    bool  drawFovCircle   = false;
    float fovRadius       = 150.0f;  // pixels

    // Colors (RGBA, 0..1)
    float colEnemy[4]     = { 1.00f, 0.20f, 0.20f, 1.00f };
    float colTeam[4]      = { 0.20f, 0.60f, 1.00f, 1.00f };
    float colText[4]      = { 1.00f, 1.00f, 1.00f, 1.00f };
    float colShadow[4]    = { 0.00f, 0.00f, 0.00f, 0.80f };
    float colCrosshair[4] = { 0.00f, 1.00f, 0.60f, 1.00f };

    // Rendering
    int   boxThickness    = 1;
    float textSize        = 13.0f;

    // Update rate for memory reads (ms between full world refreshes).
    // 0 = every frame. Raise this to reduce RPM pressure.
    int   readIntervalMs  = 0;
};

inline Config& gConfig() {
    static Config c;
    return c;
}
```


## `src/Process.h`

```cpp
// Process.h - External process attach + memory read helpers.

#pragma once

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <psapi.h>

#include <string>
#include <optional>
#include <vector>
#include <cstdint>
#include <type_traits>

#pragma comment(lib, "psapi.lib")

class Process {
public:
    Process() = default;

    ~Process() {
        detach();
    }

    // Finds a running process by executable name (case-insensitive) and opens
    // a handle with read + query rights. Returns true on success.
    bool attach(const wchar_t* exeName) {
        detach();

        const DWORD pid = findPid(exeName);
        if (!pid) return false;

        HANDLE h = OpenProcess(
            PROCESS_VM_READ | PROCESS_QUERY_INFORMATION,
            FALSE,
            pid);
        if (!h) return false;

        pid_    = pid;
        handle_ = h;

        if (!resolveModule(exeName, moduleBase_, moduleSize_)) {
            detach();
            return false;
        }
        return true;
    }

    void detach() {
        if (handle_) {
            CloseHandle(handle_);
            handle_ = nullptr;
        }
        pid_        = 0;
        moduleBase_ = 0;
        moduleSize_ = 0;
    }

    bool isAttached() const { return handle_ != nullptr; }
    DWORD pid()        const { return pid_; }
    HANDLE handle()    const { return handle_; }
    uintptr_t base()   const { return moduleBase_; }
    size_t    size()   const { return moduleSize_; }

    // Confirms the process is still running. Call periodically from the main
    // loop so the overlay can re-attach when the game exits / restarts.
    bool stillAlive() const {
        if (!handle_) return false;
        DWORD code = 0;
        if (!GetExitCodeProcess(handle_, &code)) return false;
        return code == STILL_ACTIVE;
    }

    // --- Typed memory reads ---

    template <typename T>
    bool read(uintptr_t address, T& out) const {
        static_assert(std::is_trivially_copyable_v<T>, "T must be POD-like");
        if (!handle_ || !address) return false;
        SIZE_T n = 0;
        return ReadProcessMemory(handle_, (LPCVOID)address, &out, sizeof(T), &n)
            && n == sizeof(T);
    }

    template <typename T>
    T readOr(uintptr_t address, T fallback = {}) const {
        T v{};
        return read(address, v) ? v : fallback;
    }

    bool readRaw(uintptr_t address, void* buffer, size_t bytes) const {
        if (!handle_ || !address || !buffer) return false;
        SIZE_T n = 0;
        return ReadProcessMemory(handle_, (LPCVOID)address, buffer, bytes, &n)
            && n == bytes;
    }

    // Walks a pointer chain: base -> +offset[0] -> +offset[1] -> ...
    // Returns the final address (NOT the value at it) or 0 on failure.
    uintptr_t chain(uintptr_t base, const std::vector<uintptr_t>& offsets) const {
        uintptr_t addr = base;
        for (size_t i = 0; i < offsets.size(); ++i) {
            if (i + 1 < offsets.size()) {
                if (!read<uintptr_t>(addr + offsets[i], addr) || !addr) return 0;
            } else {
                addr += offsets[i];
            }
        }
        return addr;
    }

    // Reads a fixed-size inline char string at address (NUL-terminated or
    // padded). Safe against unreadable memory.
    std::string readInlineString(uintptr_t address, size_t maxLen = 32) const {
        if (!handle_ || !address) return {};
        std::vector<char> buf(maxLen + 1, 0);
        if (!readRaw(address, buf.data(), maxLen)) return {};
        buf[maxLen] = '\0';
        return std::string(buf.data());
    }

private:
    static DWORD findPid(const wchar_t* exeName) {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (snap == INVALID_HANDLE_VALUE) return 0;

        PROCESSENTRY32W pe{ sizeof(pe) };
        DWORD pid = 0;
        if (Process32FirstW(snap, &pe)) {
            do {
                if (_wcsicmp(pe.szExeFile, exeName) == 0) {
                    pid = pe.th32ProcessID;
                    break;
                }
            } while (Process32NextW(snap, &pe));
        }
        CloseHandle(snap);
        return pid;
    }

    bool resolveModule(const wchar_t* moduleName,
                       uintptr_t& base,
                       size_t& size) const {
        base = 0;
        size = 0;

        HMODULE mods[1024];
        DWORD needed = 0;
        if (!EnumProcessModulesEx(handle_, mods, sizeof(mods), &needed,
                                  LIST_MODULES_ALL)) {
            return false;
        }
        const DWORD count = needed / sizeof(HMODULE);
        for (DWORD i = 0; i < count; ++i) {
            wchar_t name[MAX_PATH]{};
            if (!GetModuleBaseNameW(handle_, mods[i], name, _countof(name))) continue;
            if (_wcsicmp(name, moduleName) == 0) {
                MODULEINFO info{};
                if (GetModuleInformation(handle_, mods[i], &info, sizeof(info))) {
                    base = reinterpret_cast<uintptr_t>(info.lpBaseOfDll);
                    size = info.SizeOfImage;
                    return true;
                }
            }
        }
        return false;
    }

    DWORD     pid_        = 0;
    HANDLE    handle_     = nullptr;
    uintptr_t moduleBase_ = 0;
    size_t    moduleSize_ = 0;
};
```


## `src/Memory.h`

```cpp
// Memory.h - Pattern scanning for external processes.
//
// Use this to locate module-relative offsets at runtime when you only know a
// stable byte signature (IDA-style "48 8B 05 ? ? ? ?") rather than a hard
// offset. Lets the cheat survive small game patches.

#pragma once
#include "Process.h"

#include <string>
#include <vector>
#include <cstdint>
#include <sstream>
#include <optional>

namespace mem {

    struct SigByte {
        uint8_t value = 0;
        bool    wild  = false; // '?' wildcard
    };

    // Parses an IDA-style signature string: "48 8B 05 ? ? ? ? 48 85 C0".
    // Hex digits, pairs or singles; '?' or '??' means wildcard.
    inline std::vector<SigByte> parseSignature(const std::string& sig) {
        std::vector<SigByte> out;
        std::istringstream iss(sig);
        std::string token;
        while (iss >> token) {
            SigByte b;
            if (token == "?" || token == "??") {
                b.wild = true;
            } else {
                b.value = static_cast<uint8_t>(std::stoul(token, nullptr, 16));
            }
            out.push_back(b);
        }
        return out;
    }

    // Scans the given module region in the attached process for the pattern.
    // Returns the absolute address of the first match, or 0 if none.
    inline uintptr_t findPattern(const Process& proc,
                                 const std::string& sig,
                                 size_t chunkSize = 0x10000) {
        if (!proc.isAttached() || !proc.base() || !proc.size()) return 0;

        const auto pattern = parseSignature(sig);
        if (pattern.empty()) return 0;

        std::vector<uint8_t> buffer(chunkSize);
        const uintptr_t start = proc.base();
        const uintptr_t end   = proc.base() + proc.size();

        for (uintptr_t cur = start; cur < end; cur += chunkSize - pattern.size()) {
            const size_t want = (cur + chunkSize > end) ? (end - cur) : chunkSize;
            if (!proc.readRaw(cur, buffer.data(), want)) continue;

            if (want < pattern.size()) break;
            const size_t limit = want - pattern.size();
            for (size_t i = 0; i <= limit; ++i) {
                bool match = true;
                for (size_t j = 0; j < pattern.size(); ++j) {
                    if (pattern[j].wild) continue;
                    if (buffer[i + j] != pattern[j].value) { match = false; break; }
                }
                if (match) return cur + i;
            }
        }
        return 0;
    }

    // Resolves a RIP-relative instruction operand at `insnAddr + insnOffset`
    // whose instruction length is `insnLen`. Useful for turning a signature
    // hit like "48 8B 0D ? ? ? ?" into the real target address.
    //
    //   target = insnAddr + insnLen + *(int32_t*)(insnAddr + insnOffset)
    inline uintptr_t resolveRip(const Process& proc,
                                uintptr_t insnAddr,
                                size_t insnOffset,
                                size_t insnLen) {
        int32_t rel = 0;
        if (!proc.read<int32_t>(insnAddr + insnOffset, rel)) return 0;
        return insnAddr + insnLen + rel;
    }
}
```


## `src/World.h`

```cpp
// World.h - Snapshot of the game world read from the attached process.
//
// Pulls local player + entity list each tick into plain structs so the render
// thread never touches ReadProcessMemory directly. Decouples timing: reads can
// run on their own cadence (see Config::readIntervalMs) without jittering the
// overlay FPS.

#pragma once
#include "Process.h"
#include "SDK.h"
#include "Math.h"
#include "Config.h"

#include <vector>
#include <string>
#include <mutex>

struct EntitySnap {
    uintptr_t address   = 0;
    Vec3      pos       {};
    Vec3      head      {};
    float     hp        = 0.f;
    float     maxHp     = 1.f;
    int       team      = 0;
    bool      alive     = false;
    bool      visible   = true;
    bool      isLocal   = false;
    std::string name;
};

struct WorldSnap {
    bool           valid          = false;
    bool           inMatch        = true;
    Matrix4        viewMatrix     {};
    Vec3           localPos       {};
    int            localTeam      = sdk::kFallbackLocalTeam;
    uintptr_t      localAddress   = 0;
    std::vector<EntitySnap> entities;
};

class World {
public:
    // Read a complete snapshot. Returns true if the snapshot is usable (at
    // least the view matrix + local player resolved).
    bool refresh(const Process& proc) {
        WorldSnap s{};

        if (!proc.isAttached()) {
            std::lock_guard<std::mutex> lk(mtx_);
            snap_ = s;
            return false;
        }

        // View matrix
        if (sdk::off::kViewMatrix) {
            proc.read<Matrix4>(proc.base() + sdk::off::kViewMatrix, s.viewMatrix);
        }

        // Game state (optional) — bail early if clearly not in match
        if (sdk::off::kGameState) {
            int state = 0;
            if (proc.read<int>(proc.base() + sdk::off::kGameState, state)) {
                s.inMatch = (state != 0); // tune this predicate once state semantics are known
            }
        }

        // Local player
        uintptr_t localPtr = 0;
        if (sdk::off::kLocalPlayer) {
            proc.read<uintptr_t>(proc.base() + sdk::off::kLocalPlayer, localPtr);
        }
        if (localPtr) {
            s.localAddress = localPtr;
            proc.read<Vec3>(localPtr + sdk::ent::kPosition, s.localPos);
            proc.read<int>(localPtr + sdk::ent::kTeam, s.localTeam);
        }

        // Entity list
        uintptr_t listPtr = 0;
        if (sdk::off::kEntityList) {
            proc.read<uintptr_t>(proc.base() + sdk::off::kEntityList, listPtr);
        }
        int count = sdk::kMaxEntities;
        if (sdk::off::kEntityCount) {
            proc.read<int>(proc.base() + sdk::off::kEntityCount, count);
        }
        if (count < 0 || count > 4096) count = sdk::kMaxEntities;

        if (listPtr && count > 0) {
            s.entities.reserve(count);
            for (int i = 0; i < count; ++i) {
                uintptr_t ent = 0;
                if (!proc.read<uintptr_t>(listPtr + i * sdk::kEntityStride, ent) || !ent) {
                    continue;
                }
                EntitySnap e;
                e.address = ent;

                proc.read<Vec3>(ent + sdk::ent::kPosition, e.pos);
                proc.read<float>(ent + sdk::ent::kHealth, e.hp);
                proc.read<float>(ent + sdk::ent::kMaxHealth, e.maxHp);
                if (e.maxHp <= 0.f) e.maxHp = 100.f;

                proc.read<int>(ent + sdk::ent::kTeam, e.team);

                int alive = 0;
                proc.read<int>(ent + sdk::ent::kIsAlive, alive);
                e.alive = (alive != 0) && (e.hp > 0.f);

                int vis = 1;
                if (sdk::ent::kVisible) proc.read<int>(ent + sdk::ent::kVisible, vis);
                e.visible = vis != 0;

                if (sdk::ent::kBonePosHead) {
                    proc.read<Vec3>(ent + sdk::ent::kBonePosHead, e.head);
                } else {
                    e.head = { e.pos.x, e.pos.y, e.pos.z + 1.8f }; // fallback: assume ~1.8m tall
                }

                if (sdk::ent::kName) {
                    e.name = proc.readInlineString(ent + sdk::ent::kName, 32);
                }

                e.isLocal = (ent == s.localAddress);
                s.entities.push_back(std::move(e));
            }
        }

        s.valid = (sdk::off::kViewMatrix != 0 && localPtr != 0);

        {
            std::lock_guard<std::mutex> lk(mtx_);
            snap_ = std::move(s);
        }
        return snap_.valid;
    }

    WorldSnap get() const {
        std::lock_guard<std::mutex> lk(mtx_);
        return snap_;
    }

private:
    mutable std::mutex mtx_;
    WorldSnap          snap_;
};
```


## `src/Overlay.h`

```cpp
// Overlay.h - Transparent, click-through DX11 overlay window with ImGui.

#pragma once
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <dwmapi.h>

#include <string>
#include <functional>

class Overlay {
public:
    using RenderFn = std::function<void()>;

    // Attaches the overlay over the game window (looked up by title). If the
    // game window moves or resizes, syncGeometry() keeps the overlay aligned.
    bool create(const wchar_t* targetWindowTitle);
    void destroy();

    // Call every frame. Returns false when the user closed the overlay
    // (e.g. END key) or the message loop asked to exit.
    bool beginFrame();
    void endFrame();

    // Called from inside begin/end. The callback issues ImGui draw calls.
    void render(const RenderFn& fn);

    // Re-align the overlay window to the current game-window rect.
    void syncGeometry();

    // ImGui has keyboard focus when the menu is open — pass this to the
    // input layer so the game doesn't consume your typing.
    void setInteractive(bool on);

    HWND hwnd()      const { return hwnd_; }
    HWND target()    const { return target_; }
    int  width()     const { return width_; }
    int  height()    const { return height_; }

    // The DirectX device, exposed so ESP code can hand textures to ImGui if
    // needed. Normal ESP rendering goes through ImGui's draw list.
    ID3D11Device*        device()  const { return device_; }
    ID3D11DeviceContext* context() const { return ctx_; }

private:
    static LRESULT CALLBACK wndProcThunk(HWND, UINT, WPARAM, LPARAM);
    LRESULT wndProc(HWND, UINT, WPARAM, LPARAM);

    bool initD3D();
    void teardownD3D();
    void createRenderTarget();
    void releaseRenderTarget();

    HWND                 hwnd_    = nullptr;
    HWND                 target_  = nullptr;
    int                  width_   = 0;
    int                  height_  = 0;
    bool                 running_ = false;
    bool                 interactive_ = false;

    ID3D11Device*        device_  = nullptr;
    ID3D11DeviceContext* ctx_     = nullptr;
    IDXGISwapChain*      swap_    = nullptr;
    ID3D11RenderTargetView* rtv_  = nullptr;
};
```


## `src/Overlay.cpp`

```cpp
// Overlay.cpp - DX11 transparent overlay implementation.

#include "Overlay.h"

#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "dwmapi.lib")

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(
    HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

namespace {
    constexpr wchar_t kClassName[] = L"RobRunOverlayWnd_8f12";
    Overlay* gOverlayInstance = nullptr;
}

LRESULT CALLBACK Overlay::wndProcThunk(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (gOverlayInstance) return gOverlayInstance->wndProc(h, m, w, l);
    return DefWindowProcW(h, m, w, l);
}

LRESULT Overlay::wndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (ImGui_ImplWin32_WndProcHandler(h, m, w, l)) return 0;

    switch (m) {
    case WM_SIZE:
        if (device_ && w != SIZE_MINIMIZED) {
            releaseRenderTarget();
            swap_->ResizeBuffers(0, (UINT)LOWORD(l), (UINT)HIWORD(l),
                                 DXGI_FORMAT_UNKNOWN, 0);
            createRenderTarget();
            width_  = LOWORD(l);
            height_ = HIWORD(l);
        }
        return 0;
    case WM_DESTROY:
        running_ = false;
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(h, m, w, l);
}

bool Overlay::create(const wchar_t* title) {
    gOverlayInstance = this;

    target_ = FindWindowW(nullptr, title);
    if (!target_) {
        // Fall back to a full-screen overlay if the window is not found yet.
        // syncGeometry() will reattach when the window appears.
        target_ = nullptr;
    }

    WNDCLASSEXW wc{ sizeof(wc) };
    wc.style         = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc   = wndProcThunk;
    wc.hInstance     = GetModuleHandleW(nullptr);
    wc.hCursor       = LoadCursor(nullptr, IDC_ARROW);
    wc.lpszClassName = kClassName;
    RegisterClassExW(&wc);

    // WS_EX_LAYERED + WS_EX_TRANSPARENT = click-through, see-through.
    // WS_EX_TOOLWINDOW keeps the overlay out of the taskbar.
    const DWORD exStyle = WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOPMOST
                        | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE;

    hwnd_ = CreateWindowExW(
        exStyle,
        kClassName, L"RobRunOverlay",
        WS_POPUP,
        0, 0, 100, 100,
        nullptr, nullptr, wc.hInstance, nullptr);
    if (!hwnd_) return false;

    // Real transparency via DWM, not colour keying — keeps anti-aliased edges.
    MARGINS m{ -1, -1, -1, -1 };
    DwmExtendFrameIntoClientArea(hwnd_, &m);

    SetLayeredWindowAttributes(hwnd_, 0, 255, LWA_ALPHA);

    if (!initD3D()) {
        DestroyWindow(hwnd_);
        hwnd_ = nullptr;
        return false;
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NoMouseCursorChange;
    io.IniFilename = nullptr;

    ImGui::StyleColorsDark();

    ImGui_ImplWin32_Init(hwnd_);
    ImGui_ImplDX11_Init(device_, ctx_);

    ShowWindow(hwnd_, SW_SHOWNOACTIVATE);
    UpdateWindow(hwnd_);
    syncGeometry();
    running_ = true;
    return true;
}

void Overlay::destroy() {
    if (device_) {
        ImGui_ImplDX11_Shutdown();
        ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext();
    }
    teardownD3D();
    if (hwnd_) {
        DestroyWindow(hwnd_);
        hwnd_ = nullptr;
    }
    UnregisterClassW(kClassName, GetModuleHandleW(nullptr));
    gOverlayInstance = nullptr;
}

bool Overlay::initD3D() {
    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount                        = 2;
    sd.BufferDesc.Width                   = 0;
    sd.BufferDesc.Height                  = 0;
    sd.BufferDesc.Format                  = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate.Numerator   = 60;
    sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.BufferUsage                        = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow                       = hwnd_;
    sd.SampleDesc.Count                   = 1;
    sd.Windowed                           = TRUE;
    sd.SwapEffect                         = DXGI_SWAP_EFFECT_DISCARD;

    D3D_FEATURE_LEVEL got;
    const D3D_FEATURE_LEVEL want[] = { D3D_FEATURE_LEVEL_11_0 };

    HRESULT hr = D3D11CreateDeviceAndSwapChain(
        nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
        want, _countof(want), D3D11_SDK_VERSION,
        &sd, &swap_, &device_, &got, &ctx_);
    if (FAILED(hr)) return false;

    createRenderTarget();
    return true;
}

void Overlay::teardownD3D() {
    releaseRenderTarget();
    if (swap_)   { swap_->Release();   swap_ = nullptr; }
    if (ctx_)    { ctx_->Release();    ctx_ = nullptr; }
    if (device_) { device_->Release(); device_ = nullptr; }
}

void Overlay::createRenderTarget() {
    ID3D11Texture2D* back = nullptr;
    swap_->GetBuffer(0, IID_PPV_ARGS(&back));
    if (back) {
        device_->CreateRenderTargetView(back, nullptr, &rtv_);
        back->Release();
    }
}

void Overlay::releaseRenderTarget() {
    if (rtv_) { rtv_->Release(); rtv_ = nullptr; }
}

void Overlay::syncGeometry() {
    // Re-find the target window if we lost it.
    if (!target_ || !IsWindow(target_)) {
        // Caller passes the title in create(); re-search by class if needed.
    }

    RECT r{};
    if (target_ && GetClientRect(target_, &r)) {
        POINT tl{ r.left, r.top };
        ClientToScreen(target_, &tl);
        width_  = r.right - r.left;
        height_ = r.bottom - r.top;
        SetWindowPos(hwnd_, HWND_TOPMOST, tl.x, tl.y, width_, height_,
                     SWP_NOACTIVATE | SWP_SHOWWINDOW);
    } else {
        // Full-desktop fallback until the game window appears.
        const int w = GetSystemMetrics(SM_CXSCREEN);
        const int h = GetSystemMetrics(SM_CYSCREEN);
        width_  = w;
        height_ = h;
        SetWindowPos(hwnd_, HWND_TOPMOST, 0, 0, w, h,
                     SWP_NOACTIVATE | SWP_SHOWWINDOW);
    }
}

void Overlay::setInteractive(bool on) {
    if (on == interactive_) return;
    interactive_ = on;

    LONG_PTR ex = GetWindowLongPtrW(hwnd_, GWL_EXSTYLE);
    if (on) ex &= ~WS_EX_TRANSPARENT;
    else    ex |=  WS_EX_TRANSPARENT;
    SetWindowLongPtrW(hwnd_, GWL_EXSTYLE, ex);
}

bool Overlay::beginFrame() {
    MSG msg;
    while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
        if (msg.message == WM_QUIT) running_ = false;
    }
    if (!running_) return false;

    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();
    return true;
}

void Overlay::render(const RenderFn& fn) {
    if (fn) fn();
}

void Overlay::endFrame() {
    ImGui::Render();

    const float clear[4] = { 0.f, 0.f, 0.f, 0.f };
    ctx_->OMSetRenderTargets(1, &rtv_, nullptr);
    ctx_->ClearRenderTargetView(rtv_, clear);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

    swap_->Present(1, 0);
}
```


## `src/ESP.h`

```cpp
// ESP.h - ImGui-based ESP renderer.
//
// Reads the current WorldSnap + Config and emits box/name/health/snapline/
// crosshair draws onto the foreground ImGui draw list. All geometry is screen
// space; projection happens here via Math::worldToScreen.

#pragma once
#include "World.h"
#include "Config.h"
#include "Math.h"

namespace esp {

    void render(const WorldSnap& world, const Config& cfg,
                float screenW, float screenH);

    void drawMenu(Config& cfg);

}
```


## `src/ESP.cpp`

```cpp
// ESP.cpp - Overlay draw logic.

#include "ESP.h"

#include "imgui.h"

#include <cstdio>
#include <algorithm>

namespace {

    ImU32 packColor(const float c[4]) {
        return ImGui::ColorConvertFloat4ToU32(
            ImVec4(c[0], c[1], c[2], c[3]));
    }

    void outlineText(ImDrawList* dl, const ImVec2& at,
                     ImU32 fg, ImU32 shadow,
                     const char* text) {
        dl->AddText({ at.x - 1, at.y     }, shadow, text);
        dl->AddText({ at.x + 1, at.y     }, shadow, text);
        dl->AddText({ at.x,     at.y - 1 }, shadow, text);
        dl->AddText({ at.x,     at.y + 1 }, shadow, text);
        dl->AddText(at, fg, text);
    }

    void drawBox(ImDrawList* dl, const Vec2& tl, const Vec2& br,
                 ImU32 color, int thickness) {
        dl->AddRect({ tl.x, tl.y }, { br.x, br.y }, color,
                    0.0f, 0, (float)thickness);
        // Slight shadow for readability on light backgrounds
        const ImU32 shadow = IM_COL32(0, 0, 0, 160);
        dl->AddRect({ tl.x - 1, tl.y - 1 }, { br.x + 1, br.y + 1 },
                    shadow, 0.0f, 0, 1.0f);
    }

    void drawHealthBar(ImDrawList* dl, const Vec2& tl, const Vec2& br,
                       float ratio) {
        ratio = std::clamp(ratio, 0.0f, 1.0f);

        const float barW = 3.0f;
        const float x1   = tl.x - barW - 2.0f;
        const float y1   = tl.y;
        const float y2   = br.y;
        const float h    = (y2 - y1) * ratio;

        dl->AddRectFilled({ x1 - 1, y1 - 1 }, { x1 + barW + 1, y2 + 1 },
                          IM_COL32(0, 0, 0, 200));

        // HP colour: red -> yellow -> green across 0..1
        const int r = (int)((1.0f - ratio) * 255);
        const int g = (int)(ratio * 255);
        const ImU32 col = IM_COL32(r, g, 0, 255);

        dl->AddRectFilled({ x1, y2 - h }, { x1 + barW, y2 }, col);
    }

}

namespace esp {

    void render(const WorldSnap& world, const Config& cfg,
                float screenW, float screenH) {
        if (!cfg.enabled) return;

        ImDrawList* dl = ImGui::GetBackgroundDrawList();

        // Crosshair
        if (cfg.drawCrosshair) {
            const ImU32 c = packColor(cfg.colCrosshair);
            const float cx = screenW * 0.5f;
            const float cy = screenH * 0.5f;
            dl->AddLine({ cx - 6, cy }, { cx + 6, cy }, c, 1.0f);
            dl->AddLine({ cx, cy - 6 }, { cx, cy + 6 }, c, 1.0f);
        }
        if (cfg.drawFovCircle) {
            const ImU32 c = packColor(cfg.colCrosshair);
            dl->AddCircle({ screenW * 0.5f, screenH * 0.5f },
                          cfg.fovRadius, c, 64, 1.0f);
        }

        if (!world.valid || !world.inMatch) return;

        const ImU32 colEnemy  = packColor(cfg.colEnemy);
        const ImU32 colTeam   = packColor(cfg.colTeam);
        const ImU32 colText   = packColor(cfg.colText);
        const ImU32 colShadow = packColor(cfg.colShadow);

        for (const auto& e : world.entities) {
            if (!e.alive) continue;
            if (e.isLocal) continue;

            const bool friendly = (e.team == world.localTeam);
            if (cfg.espTeamCheck && friendly) continue;

            const float dist = world.localPos.distanceTo(e.pos);
            if (dist > cfg.maxDistance || dist < cfg.minDistance) continue;

            Vec2 tl, br;
            if (!worldBoxToScreen(e.pos, 1.8f, 0.6f, world.viewMatrix,
                                  screenW, screenH, tl, br)) {
                continue;
            }

            // Cull offscreen
            if (br.x < 0 || tl.x > screenW || br.y < 0 || tl.y > screenH) continue;

            const ImU32 col = friendly ? colTeam : colEnemy;

            if (cfg.espBox) {
                drawBox(dl, tl, br, col, cfg.boxThickness);
            }

            if (cfg.espHealthBar && e.maxHp > 0.0f) {
                drawHealthBar(dl, tl, br, e.hp / e.maxHp);
            }

            if (cfg.espSnapline) {
                const float cx = (tl.x + br.x) * 0.5f;
                dl->AddLine({ screenW * 0.5f, screenH },
                            { cx, br.y }, col, 1.0f);
            }

            if (cfg.espName && !e.name.empty()) {
                outlineText(dl, { tl.x, tl.y - 14 }, colText, colShadow,
                            e.name.c_str());
            }

            if (cfg.espDistance) {
                char buf[32];
                std::snprintf(buf, sizeof(buf), "[%dm]", (int)dist);
                outlineText(dl, { tl.x, br.y + 2 }, colText, colShadow, buf);
            }
        }
    }

    void drawMenu(Config& cfg) {
        ImGui::SetNextWindowSize({ 320, 480 }, ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowBgAlpha(0.88f);

        if (!ImGui::Begin("Rob Run Overlay", &cfg.showMenu,
                          ImGuiWindowFlags_NoCollapse)) {
            ImGui::End();
            return;
        }

        ImGui::Checkbox("Enabled", &cfg.enabled);
        ImGui::Separator();

        if (ImGui::CollapsingHeader("ESP", ImGuiTreeNodeFlags_DefaultOpen)) {
            ImGui::Checkbox("Box",        &cfg.espBox);
            ImGui::Checkbox("Name",       &cfg.espName);
            ImGui::Checkbox("Health bar", &cfg.espHealthBar);
            ImGui::Checkbox("Distance",   &cfg.espDistance);
            ImGui::Checkbox("Snapline",   &cfg.espSnapline);
            ImGui::Checkbox("Skeleton (requires bone offsets)", &cfg.espSkeleton);
            ImGui::Checkbox("Hide teammates", &cfg.espTeamCheck);
            ImGui::SliderInt("Box thickness", &cfg.boxThickness, 1, 4);
        }

        if (ImGui::CollapsingHeader("Filters")) {
            ImGui::SliderFloat("Max distance", &cfg.maxDistance, 0.0f, 2000.0f);
            ImGui::SliderFloat("Min distance", &cfg.minDistance, 0.0f, 500.0f);
        }

        if (ImGui::CollapsingHeader("Aim aids")) {
            ImGui::Checkbox("Crosshair",  &cfg.drawCrosshair);
            ImGui::Checkbox("FOV circle", &cfg.drawFovCircle);
            ImGui::SliderFloat("FOV radius", &cfg.fovRadius, 20.0f, 500.0f);
        }

        if (ImGui::CollapsingHeader("Colours")) {
            ImGui::ColorEdit4("Enemy",  cfg.colEnemy);
            ImGui::ColorEdit4("Team",   cfg.colTeam);
            ImGui::ColorEdit4("Text",   cfg.colText);
            ImGui::ColorEdit4("Shadow", cfg.colShadow);
            ImGui::ColorEdit4("Cross",  cfg.colCrosshair);
        }

        if (ImGui::CollapsingHeader("Perf")) {
            ImGui::SliderInt("Read interval (ms)", &cfg.readIntervalMs, 0, 50);
            ImGui::Text("FPS: %.1f", ImGui::GetIO().Framerate);
        }

        ImGui::Separator();
        ImGui::TextDisabled("INSERT = toggle menu");
        ImGui::TextDisabled("END    = quit");
        ImGui::End();
    }

}
```


## `src/main.cpp`

```cpp
// main.cpp - Rob Run external overlay entry point.
//
// Lifecycle:
//   1. Wait for RobRun.exe to appear, attach to it (Process).
//   2. Create a transparent click-through DX11 overlay over its window.
//   3. Each frame: optionally refresh the world snapshot (RPM), then draw
//      ESP + menu with ImGui.
//   4. INSERT toggles the config menu (makes the overlay interactive);
//      END quits the overlay.
//
// Build: see CMakeLists.txt. Produces RobRunOverlay.exe — run as administrator
// if the game is launched with elevation.

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include "Process.h"
#include "World.h"
#include "Overlay.h"
#include "ESP.h"
#include "Config.h"
#include "SDK.h"

#include <chrono>
#include <thread>
#include <atomic>

namespace {

    bool keyPressedEdge(int vk) {
        static bool prev[256] = {};
        const bool now = (GetAsyncKeyState(vk) & 0x8000) != 0;
        const bool edge = now && !prev[vk & 0xFF];
        prev[vk & 0xFF] = now;
        return edge;
    }

    bool waitForProcess(Process& proc, std::atomic<bool>& run) {
        while (run) {
            if (proc.attach(sdk::kProcessName)) return true;
            std::this_thread::sleep_for(std::chrono::milliseconds(750));
        }
        return false;
    }

}

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {
    // Hide the console if someone built as a console subsystem binary.
    HWND console = GetConsoleWindow();
    if (console) ShowWindow(console, SW_HIDE);

    std::atomic<bool> running{ true };

    Process proc;
    if (!waitForProcess(proc, running)) return 0;

    Overlay overlay;
    if (!overlay.create(sdk::kWindowName)) {
        proc.detach();
        return 1;
    }

    World world;
    auto lastRead = std::chrono::steady_clock::now();
    auto lastSync = std::chrono::steady_clock::now();

    Config& cfg = gConfig();

    while (overlay.beginFrame()) {
        // --- Hotkeys ---
        if (keyPressedEdge(VK_INSERT)) {
            cfg.showMenu = !cfg.showMenu;
            overlay.setInteractive(cfg.showMenu);
        }
        if (keyPressedEdge(VK_END)) {
            running = false;
            break;
        }

        // --- Process liveness ---
        if (!proc.stillAlive()) {
            proc.detach();
            if (!waitForProcess(proc, running)) break;
        }

        // --- Window geometry sync (lightweight; every ~200 ms) ---
        const auto now = std::chrono::steady_clock::now();
        if (std::chrono::duration_cast<std::chrono::milliseconds>(now - lastSync).count() >= 200) {
            overlay.syncGeometry();
            lastSync = now;
        }

        // --- World refresh ---
        const int intervalMs = cfg.readIntervalMs;
        const bool shouldRead =
            intervalMs <= 0 ||
            std::chrono::duration_cast<std::chrono::milliseconds>(now - lastRead).count() >= intervalMs;
        if (shouldRead) {
            world.refresh(proc);
            lastRead = now;
        }

        // --- Render ---
        overlay.render([&]() {
            const auto snap = world.get();
            esp::render(snap, cfg,
                        (float)overlay.width(), (float)overlay.height());

            if (cfg.showMenu) {
                esp::drawMenu(cfg);
            }
        });
        overlay.endFrame();
    }

    overlay.destroy();
    proc.detach();
    return 0;
}
```


---

# End of handoff

If you reached this line and every file in the manifest is written, you have the complete project. Proceed with sections 3 through 7 above.
